'use strict';

/* Controllers */

var phonecatControllers = angular.module('phonecatControllers', []);

phonecatControllers.controller('PhoneListCtrl', ['$scope', '$http',
  function($scope, $http) {
    $http.get('tasks/tasks.json').success(function(data) {
      $scope.tasks = data;
    });

      $scope.addTodo = function(){
        $scope.tasks.push($scope.newTask);
      }

      $scope.orderProp = 'age';

      $scope.showMe=false;

      $scope.buttonToggle = function(){
        $scope.showMe = !$scope.showMe;
      }

      $scope.oneAtATime = true;

      $scope.groups = [
          {
              title: 'Dynamic Group Header - 1',
              content: 'Dynamic Group Body - 1'
          },
          {
              title: 'Dynamic Group Header - 2',
              content: 'Dynamic Group Body - 2'
          }
      ];

      $scope.items = ['Item 1', 'Item 2', 'Item 3'];

      $scope.addItem = function() {
          var newItemNo = $scope.items.length + 1;
          $scope.items.push('Item ' + newItemNo);
      };

      $scope.status = {
          isFirstOpen: true,
          isFirstDisabled: false
      };


  }]);

phonecatControllers.controller('PhoneDetailCtrl', ['$scope', '$routeParams', '$http',
  function($scope, $routeParams, $http) {
    $http.get('tasks/' + $routeParams.phoneId + '.json').success(function(data) {
      $scope.task = data;
      $scope.mainImageUrl = data.images[0];
    });

    $scope.setImage = function(imageUrl) {
      $scope.mainImageUrl = imageUrl;
    };

  }]);

phonecatControllers.controller('Ctrl2', ['$scope',
    function($scope) {

}]);
